package com.Kpop;

import main.java.com.Kpop.ContaMagica;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ContaMagica c1 = new ContaMagica("HOJIN", "21020" );//teste
        System.out.println(c1.getNumeroConta());
        
    }
}
