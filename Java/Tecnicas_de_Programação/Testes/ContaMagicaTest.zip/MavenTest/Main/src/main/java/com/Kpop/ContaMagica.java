package main.java.com.Kpop;

public class ContaMagica {
    String nome, categoria, numeroConta;
    double saldo;

    public ContaMagica(String nome, String numeroConta) {
        this.nome = nome;
        this.numeroConta = numeroConta;
        this.categoria = "silver";
        this.saldo = 0;
    }
    

    public String getNumeroConta() {
        return this.numeroConta;
    }

    public String getNomeCorrentista() {
        return this.nome;
    }

    public double getSaldo() {
        return this.saldo;
    }

    public String getCategoria() {
        return this.categoria;
    }

    public boolean deposito(double valor){

    if(this.getCategoria().equals("silver") ){
        this.saldo+= valor;
        if(this.getSaldo()>= 50000){
            this.categoria="gold";
        }
    }
    else if( this.getCategoria().equals("gold")){
        this.saldo+= valor* 1.01;
        if(this.getSaldo()>= 200000){
            this.categoria="platinum";
        }
    }

    else if(this.getCategoria().equals("platinum")){
        this.saldo+= valor* 1.025;
    }
        return true;
    }

    public boolean retirada(double valor) {
        if (this.getCategoria().equals("silver")) {
            this.saldo -= valor;

        } else if (this.getCategoria().equals("gold")) {
            this.saldo -= valor;
            if (this.saldo < 25000) {
                this.categoria = "silver";
            }

        }

        else if (this.getCategoria().equals("platinum")) {
            this.saldo -= valor;
            if (this.saldo < 100000) {
                this.categoria = "gold";
            }

        }
        return true;

    }
}