package test.java.com.Kpop;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

import main.java.com.Kpop.ContaMagica;

public class ContaMagicaTest {
    private ContaMagica a;
    private ContaMagica b;
    private ContaMagica c;
    private ContaMagica d;
    private ContaMagica e;
    private ContaMagica f;
    private ContaMagica g;
    

    @BeforeEach
    void setUp(){
        a = new ContaMagica("Hojiin", "2000000"); 
        b = new ContaMagica("Bruno", "1123000"); 
        c = new ContaMagica("Heitor", "321000"); 
        d = new ContaMagica("Luiza", "20023320"); 

        e= new ContaMagica("Matheus", "2055320"); 
        f= new ContaMagica("Claudio", "55523320"); 
        g= new ContaMagica("Rosa", "66623320"); 
    }


    @Test
    public void contaTest(){
        a.deposito(20000);

        b.deposito(50000);
        b.deposito(100);

        c.deposito(50000);
        c.deposito(150000);
        c.deposito(100000);

        d.deposito(50000);
        d.retirada(26000);

        e.deposito(50000);
        e.deposito(150000);
        e.deposito(100000);
        e.retirada(205000);

        f.deposito(50000);
        f.deposito(150000);
        f.deposito(100000);
        f.retirada(205000);
        f.retirada(75000);

        assertEquals("2000000", a.getNumeroConta());
        assertEquals(20000,a.getSaldo());
        assertEquals("silver", a.getCategoria());

        assertEquals(50101,b.getSaldo());
        assertEquals("gold",b.getCategoria());
        assertEquals("Bruno", b.getNomeCorrentista());

        assertEquals(304000, c.getSaldo());

        assertEquals("silver", d.getCategoria());

        assertEquals("gold",e.getCategoria());

        assertEquals("silver",f.getCategoria() );
        
    }

}