package com.TecKpop;

public class Funcionario {
    String nome;
    double salarioBruto;
    double salarioLiquido,INSS, IR;
    Funcionario(double salario){
        this.salarioBruto=salario;
        this.INSS= INSS();
        this.IR= IR();
        this.salarioLiquido= this.salarioBruto- IR - INSS;
    }
    public double INSS(){
        double inss=this.salarioBruto * 0.045;
        if(inss>5000){
            inss=5000;
        }
        return inss;
    }
    public double IR(){
        double ir;
        if(this.salarioBruto>2500){
            ir= this.salarioBruto * 0.12;
            return ir;
        }
        return 0;
    }

    public double getINSS(){
        return INSS;
    }

    public double getIR(){
        return IR;
    }

    public double salarioBruto(){
        return salarioBruto;
    }

    public double salarioLiquido(){
        return salarioLiquido;
    }

    public double getSalarioBruto(){
        return salarioBruto;
    }
    public double getSalarioLiquido(){
        return salarioLiquido;
    }
}