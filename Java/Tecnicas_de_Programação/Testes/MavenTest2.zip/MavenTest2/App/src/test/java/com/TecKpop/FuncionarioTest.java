package com.TecKpop;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;


public class FuncionarioTest {
    private Funcionario a;
    private Funcionario b;
    private Funcionario c;

    @BeforeEach
    void setUp(){
       a = new Funcionario(1000);
       b = new Funcionario(2501);
       c = new Funcionario(200000);
    }


    @Test
    public void contaTest(){

        assertEquals(1000, a.getSalarioBruto());
        assertEquals(45,a.getINSS());
        assertEquals(0, a.getIR());
        assertEquals(955,a.getSalarioLiquido());

        assertEquals(2088.335,b.getSalarioLiquido());
        assertEquals(2501 * 0.12 , b.getIR());
        
        assertEquals(171000, c.getSalarioLiquido());
        assertEquals(5000, c.getINSS());

    }

}